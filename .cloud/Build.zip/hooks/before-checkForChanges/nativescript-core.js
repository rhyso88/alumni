module.exports = require("@nativescript/core/cli-hooks/before-checkForChanges.js");
